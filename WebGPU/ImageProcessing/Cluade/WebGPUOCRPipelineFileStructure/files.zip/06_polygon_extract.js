/**
 * Stage 6: Polygon Extraction
 * Extract text region polygons from binary detection map
 */

export class PolygonExtract {
  constructor(gpuContext) {
    this.gpu = gpuContext;
    this.pipelines = {};
  }

  async initialize() {
    // Connected components labeling
    this.pipelines.ccl = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var binaryMap: texture_2d<f32>;
            @group(0) @binding(1) var<storage, read_write> labels: array<atomic<u32>>;

            @compute @workgroup_size(8, 8)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(binaryMap);
              if (id.x >= dims.x || id.y >= dims.y) { return; }

              let pixel = textureLoad(binaryMap, vec2<i32>(id.xy), 0).r;
              if (pixel < 0.5) { return; }

              let idx = id.y * dims.x + id.x;
              
              // Initialize label
              atomicStore(&labels[idx], idx);
              
              // Check 4-connected neighbors
              if (id.x > 0u) {
                let left = textureLoad(binaryMap, vec2<i32>(i32(id.x) - 1, i32(id.y)), 0).r;
                if (left > 0.5) {
                  let leftIdx = id.y * dims.x + id.x - 1u;
                  atomicMin(&labels[idx], atomicLoad(&labels[leftIdx]));
                }
              }
              
              if (id.y > 0u) {
                let top = textureLoad(binaryMap, vec2<i32>(i32(id.x), i32(id.y) - 1), 0).r;
                if (top > 0.5) {
                  let topIdx = (id.y - 1u) * dims.x + id.x;
                  atomicMin(&labels[idx], atomicLoad(&labels[topIdx]));
                }
              }
            }
          `
        }),
        entryPoint: 'main'
      }
    });

    // Contour tracing
    this.pipelines.contour = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var<storage, read> labels: array<u32>;
            @group(0) @binding(1) var<storage, read_write> contours: array<vec2<f32>>;
            @group(0) @binding(2) var<storage, read_write> contourLengths: array<atomic<u32>>;
            @group(0) @binding(3) var<uniform> dims: vec2<u32>;

            @compute @workgroup_size(256)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let totalPixels = dims.x * dims.y;
              if (id.x >= totalPixels) { return; }

              let label = labels[id.x];
              if (label == 0u) { return; }

              let x = id.x % dims.x;
              let y = id.x / dims.x;

              // Check if this is a boundary pixel
              var isBoundary = false;
              if (x == 0u || x == dims.x - 1u || y == 0u || y == dims.y - 1u) {
                isBoundary = true;
              } else {
                // Check 8-neighbors
                for (var dy = -1; dy <= 1; dy++) {
                  for (var dx = -1; dx <= 1; dx++) {
                    if (dx == 0 && dy == 0) { continue; }
                    let nx = i32(x) + dx;
                    let ny = i32(y) + dy;
                    let nidx = u32(ny) * dims.x + u32(nx);
                    if (labels[nidx] != label) {
                      isBoundary = true;
                    }
                  }
                }
              }

              if (isBoundary) {
                let contourIdx = atomicAdd(&contourLengths[label], 1u);
                contours[label * 10000u + contourIdx] = vec2<f32>(f32(x), f32(y));
              }
            }
          `
        }),
        entryPoint: 'main'
      }
    });
  }

  async extract(binaryMap) {
    const width = binaryMap.width;
    const height = binaryMap.height;

    // Connected components
    const labelsBuffer = this.gpu.createBuffer(
      width * height * 4,
      GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC
    );

    let bindGroup = this.gpu.createBindGroup(
      this.pipelines.ccl.getBindGroupLayout(0),
      [
        { binding: 0, resource: binaryMap.createView() },
        { binding: 1, resource: { buffer: labelsBuffer } }
      ]
    );

    let encoder = this.gpu.createCommandEncoder();
    let pass = encoder.beginComputePass();
    pass.setPipeline(this.pipelines.ccl);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(width / 8), Math.ceil(height / 8));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    // Extract contours
    const maxComponents = 1000;
    const contoursBuffer = this.gpu.createBuffer(
      maxComponents * 10000 * 8, // max 10000 points per contour
      GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC
    );

    const contourLengthsBuffer = this.gpu.createBuffer(
      maxComponents * 4,
      GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC
    );

    const dimsBuffer = this.gpu.createBuffer(8, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST);
    this.gpu.writeBuffer(dimsBuffer, new Uint32Array([width, height]));

    bindGroup = this.gpu.createBindGroup(
      this.pipelines.contour.getBindGroupLayout(0),
      [
        { binding: 0, resource: { buffer: labelsBuffer } },
        { binding: 1, resource: { buffer: contoursBuffer } },
        { binding: 2, resource: { buffer: contourLengthsBuffer } },
        { binding: 3, resource: { buffer: dimsBuffer } }
      ]
    );

    encoder = this.gpu.createCommandEncoder();
    pass = encoder.beginComputePass();
    pass.setPipeline(this.pipelines.contour);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(width * height / 256));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    // Read results
    const lengthsData = await this.gpu.readBuffer(contourLengthsBuffer);
    const lengths = new Uint32Array(lengthsData.buffer);

    const contoursData = await this.gpu.readBuffer(contoursBuffer);
    const contours = new Float32Array(contoursData.buffer);

    // Convert to polygon list
    const polygons = [];
    for (let i = 0; i < maxComponents; i++) {
      const length = lengths[i];
      if (length > 4) { // Minimum 4 points for a valid polygon
        const points = [];
        for (let j = 0; j < length; j++) {
          const idx = i * 10000 + j;
          points.push({
            x: contours[idx * 2],
            y: contours[idx * 2 + 1]
          });
        }
        
        // Simplify polygon (Douglas-Peucker)
        const simplified = this.simplifyPolygon(points, 2.0);
        if (simplified.length >= 4) {
          polygons.push(simplified);
        }
      }
    }

    labelsBuffer.destroy();
    contoursBuffer.destroy();
    contourLengthsBuffer.destroy();
    dimsBuffer.destroy();

    return polygons;
  }

  simplifyPolygon(points, epsilon) {
    if (points.length < 3) return points;

    // Douglas-Peucker algorithm
    let dmax = 0;
    let index = 0;
    const end = points.length - 1;

    for (let i = 1; i < end; i++) {
      const d = this.perpendicularDistance(points[i], points[0], points[end]);
      if (d > dmax) {
        index = i;
        dmax = d;
      }
    }

    if (dmax > epsilon) {
      const left = this.simplifyPolygon(points.slice(0, index + 1), epsilon);
      const right = this.simplifyPolygon(points.slice(index), epsilon);
      return left.slice(0, -1).concat(right);
    } else {
      return [points[0], points[end]];
    }
  }

  perpendicularDistance(point, lineStart, lineEnd) {
    const dx = lineEnd.x - lineStart.x;
    const dy = lineEnd.y - lineStart.y;
    const norm = Math.sqrt(dx * dx + dy * dy);
    if (norm === 0) return 0;
    
    return Math.abs((point.x - lineStart.x) * dy - (point.y - lineStart.y) * dx) / norm;
  }

  dispose() {}
}
