/**
 * Connected Component Analysis
 * Label connected regions in binary images
 */

export class CCA {
  constructor(gpuContext) {
    this.gpu = gpuContext;
  }

  async initialize() {
    this.pipeline = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var inputTexture: texture_2d<f32>;
            @group(0) @binding(1) var<storage, read_write> labels: array<atomic<u32>>;

            fn findRoot(labels: ptr<storage, array<atomic<u32>>, read_write>, idx: u32) -> u32 {
              var current = idx;
              var parent = atomicLoad(&(*labels)[current]);
              
              while (parent != current) {
                current = parent;
                parent = atomicLoad(&(*labels)[current]);
              }
              
              return current;
            }

            @compute @workgroup_size(8, 8)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(inputTexture);
              if (id.x >= dims.x || id.y >= dims.y) { return; }

              let pixel = textureLoad(inputTexture, vec2<i32>(id.xy), 0).r;
              if (pixel < 0.5) { return; }

              let idx = id.y * dims.x + id.x;
              atomicStore(&labels[idx], idx);

              // Check 4-connected neighbors
              if (id.x > 0u) {
                let left = textureLoad(inputTexture, vec2<i32>(i32(id.x) - 1, i32(id.y)), 0).r;
                if (left > 0.5) {
                  let leftIdx = id.y * dims.x + id.x - 1u;
                  atomicMin(&labels[idx], leftIdx);
                }
              }

              if (id.y > 0u) {
                let top = textureLoad(inputTexture, vec2<i32>(i32(id.x), i32(id.y) - 1), 0).r;
                if (top > 0.5) {
                  let topIdx = (id.y - 1u) * dims.x + id.x;
                  atomicMin(&labels[idx], topIdx);
                }
              }
            }
          `
        }),
        entryPoint: 'main'
      }
    });
  }

  async label(binaryTexture) {
    const width = binaryTexture.width;
    const height = binaryTexture.height;

    const labelsBuffer = this.gpu.createBuffer(
      width * height * 4,
      GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC
    );

    const bindGroup = this.gpu.createBindGroup(
      this.pipeline.getBindGroupLayout(0),
      [
        { binding: 0, resource: binaryTexture.createView() },
        { binding: 1, resource: { buffer: labelsBuffer } }
      ]
    );

    const encoder = this.gpu.createCommandEncoder();
    const pass = encoder.beginComputePass();
    pass.setPipeline(this.pipeline);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(width / 8), Math.ceil(height / 8));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    return labelsBuffer;
  }

  dispose() {}
}
