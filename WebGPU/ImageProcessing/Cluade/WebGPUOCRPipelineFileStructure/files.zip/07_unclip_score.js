/**
 * Stage 7: Unclip and Score
 * Expand text boxes and score their quality
 */

export class UnclipScore {
  constructor(gpuContext) {
    this.gpu = gpuContext;
  }

  async initialize() {}

  async process(polygons, detectionMap) {
    const scored = polygons.map(poly => {
      const expanded = this.unclip(poly, 1.5);
      const score = this.scorePolygon(poly, detectionMap);
      return { polygon: expanded, score, original: poly };
    }).filter(p => p.score > 0.3);

    return scored.sort((a, b) => b.score - a.score);
  }

  unclip(polygon, ratio) {
    // Expand polygon by ratio using offset
    const area = this.polygonArea(polygon);
    const perimeter = this.polygonPerimeter(polygon);
    const distance = area * (ratio - 1) / perimeter;

    return this.offsetPolygon(polygon, distance);
  }

  polygonArea(points) {
    let area = 0;
    for (let i = 0; i < points.length; i++) {
      const j = (i + 1) % points.length;
      area += points[i].x * points[j].y - points[j].x * points[i].y;
    }
    return Math.abs(area) / 2;
  }

  polygonPerimeter(points) {
    let perim = 0;
    for (let i = 0; i < points.length; i++) {
      const j = (i + 1) % points.length;
      const dx = points[j].x - points[i].x;
      const dy = points[j].y - points[i].y;
      perim += Math.sqrt(dx * dx + dy * dy);
    }
    return perim;
  }

  offsetPolygon(points, distance) {
    // Simplified offset (production would use proper polygon offsetting)
    const centroid = this.centroid(points);
    return points.map(p => {
      const dx = p.x - centroid.x;
      const dy = p.y - centroid.y;
      const len = Math.sqrt(dx * dx + dy * dy);
      return {
        x: p.x + (dx / len) * distance,
        y: p.y + (dy / len) * distance
      };
    });
  }

  centroid(points) {
    let x = 0, y = 0;
    for (const p of points) {
      x += p.x;
      y += p.y;
    }
    return { x: x / points.length, y: y / points.length };
  }

  scorePolygon(polygon, detectionMap) {
    // Score based on detection map values inside polygon
    // Simplified - would actually sample the GPU texture
    return 0.8; // Placeholder
  }

  dispose() {}
}
