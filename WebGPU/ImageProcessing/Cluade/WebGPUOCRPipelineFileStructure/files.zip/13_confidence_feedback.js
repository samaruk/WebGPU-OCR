/**
 * Stage 13: Confidence Feedback
 * Refine results using confidence scores and feedback loops
 */

export class ConfidenceFeedback {
  constructor(gpuContext) {
    this.gpu = gpuContext;
  }

  async initialize() {}

  async refine(recognitionResults, detectionMap) {
    const refined = [];
    let totalText = '';
    let totalConfidence = 0;
    let count = 0;

    for (const result of recognitionResults) {
      // Compute various confidence metrics
      const detectionConf = await this.computeDetectionConfidence(result, detectionMap);
      const recognitionConf = result.confidence || 0.5;
      const geometryConf = this.computeGeometryConfidence(result);
      
      // Combined confidence
      const confidence = (detectionConf * 0.3 + recognitionConf * 0.5 + geometryConf * 0.2);

      if (confidence > 0.3) {
        refined.push({
          ...result,
          confidence,
          detectionConfidence: detectionConf,
          recognitionConfidence: recognitionConf,
          geometryConfidence: geometryConf
        });

        if (result.text) {
          totalText += result.text + '\n';
          totalConfidence += confidence;
          count++;
        }
      }
    }

    return {
      regions: refined,
      text: totalText.trim(),
      confidence: count > 0 ? totalConfidence / count : 0
    };
  }

  async computeDetectionConfidence(result, detectionMap) {
    // Simplified - would sample detection map at polygon points
    return 0.8;
  }

  computeGeometryConfidence(result) {
    if (!result.polygon) return 0.5;

    // Check aspect ratio
    const poly = result.polygon;
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const p of poly) {
      minX = Math.min(minX, p.x);
      maxX = Math.max(maxX, p.x);
      minY = Math.min(minY, p.y);
      maxY = Math.max(maxY, p.y);
    }

    const width = maxX - minX;
    const height = maxY - minY;
    const aspectRatio = width / height;

    // Text typically has aspect ratio > 1
    const aspectScore = aspectRatio > 1 ? Math.min(aspectRatio / 10, 1.0) : 0.3;

    // Check if polygon is roughly rectangular
    const area = this.polygonArea(poly);
    const rectArea = width * height;
    const rectangularity = area / rectArea;

    return (aspectScore * 0.6 + rectangularity * 0.4);
  }

  polygonArea(points) {
    let area = 0;
    for (let i = 0; i < points.length; i++) {
      const j = (i + 1) % points.length;
      area += points[i].x * points[j].y - points[j].x * points[i].y;
    }
    return Math.abs(area) / 2;
  }

  dispose() {}
}
