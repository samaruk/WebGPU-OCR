/**
 * Stage 4: Adaptive Enhancement
 * Uses textness map to selectively enhance text regions
 */

export class AdaptiveEnhance {
  constructor(gpuContext) {
    this.gpu = gpuContext;
    this.pipeline = null;
  }

  async initialize() {
    this.pipeline = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var inputTexture: texture_2d<f32>;
            @group(0) @binding(1) var textnessTexture: texture_2d<f32>;
            @group(0) @binding(2) var outputTexture: texture_storage_2d<rgba8unorm, write>;

            fn adaptiveThreshold(value: f32, localMean: f32, localStd: f32, k: f32) -> f32 {
              let threshold = localMean * (1.0 + k * ((localStd / 128.0) - 1.0));
              return select(0.0, 1.0, value > threshold);
            }

            @compute @workgroup_size(8, 8)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(inputTexture);
              if (id.x >= dims.x || id.y >= dims.y) { return; }

              let textness = textureLoad(textnessTexture, vec2<i32>(id.xy), 0).r;
              let pixel = textureLoad(inputTexture, vec2<i32>(id.xy), 0);
              let gray = 0.299 * pixel.r + 0.587 * pixel.g + 0.114 * pixel.b;

              // Compute local statistics
              let windowSize = 15;
              var localSum = 0.0;
              var localSqSum = 0.0;
              var count = 0.0;

              for (var dy = -windowSize; dy <= windowSize; dy++) {
                for (var dx = -windowSize; dx <= windowSize; dx++) {
                  let px = clamp(i32(id.x) + dx, 0, i32(dims.x) - 1);
                  let py = clamp(i32(id.y) + dy, 0, i32(dims.y) - 1);
                  let p = textureLoad(inputTexture, vec2<i32>(px, py), 0);
                  let g = 0.299 * p.r + 0.587 * p.g + 0.114 * p.b;
                  localSum += g;
                  localSqSum += g * g;
                  count += 1.0;
                }
              }

              let localMean = localSum / count;
              let localVar = (localSqSum / count) - (localMean * localMean);
              let localStd = sqrt(max(localVar, 0.0));

              // Adaptive enhancement based on textness
              var enhanced = gray;
              if (textness > 0.5) {
                // High textness: apply adaptive binarization
                enhanced = adaptiveThreshold(gray, localMean, localStd, 0.15);
              } else if (textness > 0.2) {
                // Medium textness: apply CLAHE-like enhancement
                let contrast = (gray - localMean) / max(localStd, 0.01);
                enhanced = clamp(0.5 + contrast * 0.3, 0.0, 1.0);
              }
              // else: low textness, keep original

              textureStore(outputTexture, vec2<i32>(id.xy), vec4<f32>(enhanced, enhanced, enhanced, 1.0));
            }
          `
        }),
        entryPoint: 'main'
      }
    });
  }

  async process(imageData, textnessMap) {
    const { width, height } = imageData;

    const inputTexture = this.gpu.createTexture({
      size: { width, height },
      format: 'rgba8unorm',
      usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST
    });

    const outputTexture = this.gpu.createTexture({
      size: { width, height },
      format: 'rgba8unorm',
      usage: GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.COPY_SRC
    });

    this.gpu.queue.writeTexture(
      { texture: inputTexture },
      imageData.data,
      { bytesPerRow: width * 4 },
      { width, height }
    );

    const bindGroup = this.gpu.createBindGroup(
      this.pipeline.getBindGroupLayout(0),
      [
        { binding: 0, resource: inputTexture.createView() },
        { binding: 1, resource: textnessMap.createView() },
        { binding: 2, resource: outputTexture.createView() }
      ]
    );

    const encoder = this.gpu.createCommandEncoder();
    const pass = encoder.beginComputePass();
    pass.setPipeline(this.pipeline);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(width / 8), Math.ceil(height / 8));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    inputTexture.destroy();
    return outputTexture;
  }

  dispose() {}
}
