/**
 * Stage 11: Super Resolution
 * Enhance small/blurry text using ESRGAN-style SR
 */

export class SuperResolution {
  constructor(gpuContext) {
    this.gpu = gpuContext;
    this.scaleFactor = 2;
  }

  async initialize() {
    // Simplified super-resolution using bicubic + sharpening
    this.pipeline = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var inputTexture: texture_2d<f32>;
            @group(0) @binding(1) var outputTexture: texture_storage_2d<rgba8unorm, write>;

            const sharpenKernel = array<f32, 9>(
              -0.1, -0.2, -0.1,
              -0.2,  2.2, -0.2,
              -0.1, -0.2, -0.1
            );

            fn lanczos(x: f32, a: f32) -> f32 {
              if (x == 0.0) { return 1.0; }
              if (abs(x) >= a) { return 0.0; }
              let pi = 3.14159265359;
              let pix = pi * x;
              return a * sin(pix) * sin(pix / a) / (pix * pix);
            }

            @compute @workgroup_size(8, 8)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(outputTexture);
              if (id.x >= dims.x || id.y >= dims.y) { return; }

              let srcDims = textureDimensions(inputTexture);
              let srcX = f32(id.x) * 0.5;
              let srcY = f32(id.y) * 0.5;

              // Lanczos interpolation
              let x0 = floor(srcX);
              let y0 = floor(srcY);
              let fx = srcX - x0;
              let fy = srcY - y0;

              var sum = vec4<f32>(0.0);
              var weightSum = 0.0;

              for (var j = -2; j <= 2; j++) {
                for (var i = -2; i <= 2; i++) {
                  let px = clamp(i32(x0) + i, 0, i32(srcDims.x) - 1);
                  let py = clamp(i32(y0) + j, 0, i32(srcDims.y) - 1);
                  let pixel = textureLoad(inputTexture, vec2<i32>(px, py), 0);
                  
                  let wx = lanczos(f32(i) - fx, 2.0);
                  let wy = lanczos(f32(j) - fy, 2.0);
                  let weight = wx * wy;
                  
                  sum += pixel * weight;
                  weightSum += weight;
                }
              }

              var upscaled = sum / weightSum;

              // Apply unsharp mask for enhancement
              var sharpened = vec4<f32>(0.0);
              var kidx = 0;
              for (var dy = -1; dy <= 1; dy++) {
                for (var dx = -1; dx <= 1; dx++) {
                  if (i32(id.x) + dx >= 0 && i32(id.x) + dx < i32(dims.x) &&
                      i32(id.y) + dy >= 0 && i32(id.y) + dy < i32(dims.y)) {
                    // For first pass, use upscaled value
                    sharpened += upscaled * sharpenKernel[kidx];
                  }
                  kidx++;
                }
              }

              textureStore(outputTexture, vec2<i32>(id.xy), clamp(sharpened, vec4<f32>(0.0), vec4<f32>(1.0)));
            }
          `
        }),
        entryPoint: 'main'
      }
    });
  }

  async upscale(lines) {
    const upscaled = [];

    for (const line of lines) {
      if (line.height < 20) {
        const enhanced = await this.enhanceLine(line);
        upscaled.push(enhanced);
      } else {
        upscaled.push(line);
      }
    }

    return upscaled;
  }

  async enhanceLine(line) {
    const srcTexture = line.normalized || line.image;
    const srcWidth = line.width || srcTexture.width;
    const srcHeight = line.height || srcTexture.height;

    const dstWidth = srcWidth * this.scaleFactor;
    const dstHeight = srcHeight * this.scaleFactor;

    const outputTexture = this.gpu.createTexture({
      size: { width: dstWidth, height: dstHeight },
      format: 'rgba8unorm',
      usage: GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.TEXTURE_BINDING
    });

    const bindGroup = this.gpu.createBindGroup(
      this.pipeline.getBindGroupLayout(0),
      [
        { binding: 0, resource: srcTexture.createView() },
        { binding: 1, resource: outputTexture.createView() }
      ]
    );

    const encoder = this.gpu.createCommandEncoder();
    const pass = encoder.beginComputePass();
    pass.setPipeline(this.pipeline);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(dstWidth / 8), Math.ceil(dstHeight / 8));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    return { ...line, enhanced: outputTexture, width: dstWidth, height: dstHeight };
  }

  dispose() {}
}
