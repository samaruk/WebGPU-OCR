/**
 * Tensor - GPU Tensor abstraction for neural network operations
 */

export class Tensor {
  constructor(gpuContext, shape, dtype = 'float32') {
    this.gpu = gpuContext;
    this.shape = shape;
    this.dtype = dtype;
    this.size = shape.reduce((a, b) => a * b, 1);
    
    this.buffer = null;
    this.texture = null;
    this.storageType = 'buffer'; // 'buffer' or 'texture'
  }

  get rank() {
    return this.shape.length;
  }

  get byteSize() {
    const bytesPerElement = this.dtype === 'float32' ? 4 : 
                            this.dtype === 'float16' ? 2 : 1;
    return this.size * bytesPerElement;
  }

  allocateBuffer() {
    this.buffer = this.gpu.createBuffer(
      this.byteSize,
      GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST,
      `tensor-${this.shape.join('x')}`
    );
    this.storageType = 'buffer';
    return this;
  }

  allocateTexture(format = 'rgba8unorm') {
    if (this.rank !== 2 && this.rank !== 3) {
      throw new Error('Texture storage requires 2D or 3D tensors');
    }

    const [height, width, channels = 4] = this.shape;
    
    this.texture = this.gpu.createTexture({
      size: { width, height, depthOrArrayLayers: 1 },
      format,
      usage: GPUTextureUsage.STORAGE_BINDING | 
             GPUTextureUsage.TEXTURE_BINDING | 
             GPUTextureUsage.COPY_SRC | 
             GPUTextureUsage.COPY_DST,
      label: `tensor-texture-${this.shape.join('x')}`
    });
    this.storageType = 'texture';
    return this;
  }

  async fromArray(data) {
    if (data.length !== this.size) {
      throw new Error(`Data size ${data.length} doesn't match tensor size ${this.size}`);
    }

    if (!this.buffer) {
      this.allocateBuffer();
    }

    const typedData = this.dtype === 'float32' ? new Float32Array(data) :
                      this.dtype === 'float16' ? new Uint16Array(data) :
                      new Uint8Array(data);

    this.gpu.writeBuffer(this.buffer, typedData);
    return this;
  }

  async toArray() {
    if (!this.buffer) {
      throw new Error('No buffer allocated');
    }

    const data = await this.gpu.readBuffer(this.buffer);
    
    if (this.dtype === 'float32') {
      return new Float32Array(data.buffer);
    } else if (this.dtype === 'float16') {
      return new Uint16Array(data.buffer);
    }
    return data;
  }

  reshape(newShape) {
    const newSize = newShape.reduce((a, b) => a * b, 1);
    if (newSize !== this.size) {
      throw new Error(`Cannot reshape tensor of size ${this.size} to ${newSize}`);
    }
    this.shape = newShape;
    return this;
  }

  transpose(axes) {
    // Implementation would create new tensor with transposed data
    throw new Error('Transpose not yet implemented');
  }

  clone() {
    const newTensor = new Tensor(this.gpu, [...this.shape], this.dtype);
    newTensor.allocateBuffer();

    const encoder = this.gpu.createCommandEncoder('tensor-clone');
    encoder.copyBufferToBuffer(this.buffer, 0, newTensor.buffer, 0, this.byteSize);
    this.gpu.submit([encoder.finish()]);

    return newTensor;
  }

  dispose() {
    if (this.buffer) {
      this.buffer.destroy();
      this.buffer = null;
    }
    if (this.texture) {
      this.texture.destroy();
      this.texture = null;
    }
  }

  // Static factory methods
  static zeros(gpuContext, shape, dtype = 'float32') {
    const tensor = new Tensor(gpuContext, shape, dtype);
    tensor.allocateBuffer();
    const size = shape.reduce((a, b) => a * b, 1);
    const zeros = new Float32Array(size);
    gpuContext.writeBuffer(tensor.buffer, zeros);
    return tensor;
  }

  static ones(gpuContext, shape, dtype = 'float32') {
    const tensor = new Tensor(gpuContext, shape, dtype);
    tensor.allocateBuffer();
    const size = shape.reduce((a, b) => a * b, 1);
    const ones = new Float32Array(size).fill(1.0);
    gpuContext.writeBuffer(tensor.buffer, ones);
    return tensor;
  }

  static fromImageData(gpuContext, imageData) {
    const { width, height, data } = imageData;
    const tensor = new Tensor(gpuContext, [height, width, 4], 'float32');
    
    // Normalize to [0, 1]
    const normalized = new Float32Array(data.length);
    for (let i = 0; i < data.length; i++) {
      normalized[i] = data[i] / 255.0;
    }
    
    tensor.allocateBuffer();
    gpuContext.writeBuffer(tensor.buffer, normalized);
    return tensor;
  }
}

/**
 * TensorOps - Common tensor operations on GPU
 */
export class TensorOps {
  constructor(gpuContext) {
    this.gpu = gpuContext;
    this.pipelines = {};
  }

  async matmul(a, b, c = null) {
    if (a.shape[1] !== b.shape[0]) {
      throw new Error(`Incompatible shapes for matmul: ${a.shape} x ${b.shape}`);
    }

    const M = a.shape[0];
    const K = a.shape[1];
    const N = b.shape[1];

    if (!c) {
      c = new Tensor(this.gpu, [M, N], a.dtype);
      c.allocateBuffer();
    }

    if (!this.pipelines.matmul) {
      this.pipelines.matmul = this.gpu.createComputePipeline({
        layout: 'auto',
        compute: {
          module: this.gpu.device.createShaderModule({
            code: `
              @group(0) @binding(0) var<storage, read> a: array<f32>;
              @group(0) @binding(1) var<storage, read> b: array<f32>;
              @group(0) @binding(2) var<storage, read_write> c: array<f32>;
              @group(0) @binding(3) var<uniform> dims: vec3<u32>; // M, K, N

              @compute @workgroup_size(8, 8)
              fn main(@builtin(global_invocation_id) id: vec3<u32>) {
                let M = dims.x;
                let K = dims.y;
                let N = dims.z;
                
                let row = id.x;
                let col = id.y;
                
                if (row >= M || col >= N) { return; }
                
                var sum = 0.0;
                for (var k = 0u; k < K; k++) {
                  sum += a[row * K + k] * b[k * N + col];
                }
                c[row * N + col] = sum;
              }
            `
          }),
          entryPoint: 'main'
        }
      });
    }

    // Create uniform buffer for dimensions
    const dimsBuffer = this.gpu.createBuffer(
      12,
      GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
      'matmul-dims'
    );
    this.gpu.writeBuffer(dimsBuffer, new Uint32Array([M, K, N]));

    // Create bind group
    const bindGroup = this.gpu.createBindGroup(
      this.pipelines.matmul.getBindGroupLayout(0),
      [
        { binding: 0, resource: { buffer: a.buffer } },
        { binding: 1, resource: { buffer: b.buffer } },
        { binding: 2, resource: { buffer: c.buffer } },
        { binding: 3, resource: { buffer: dimsBuffer } }
      ],
      'matmul-bind-group'
    );

    // Execute
    const encoder = this.gpu.createCommandEncoder('matmul');
    const pass = encoder.beginComputePass();
    pass.setPipeline(this.pipelines.matmul);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(M / 8), Math.ceil(N / 8));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    dimsBuffer.destroy();

    return c;
  }

  async conv2d(input, kernel, bias = null, stride = 1, padding = 0) {
    // Simplified 2D convolution
    // Full implementation would include optimized tiled convolution
    throw new Error('Conv2d not yet implemented');
  }

  async relu(input, output = null) {
    if (!output) {
      output = new Tensor(this.gpu, input.shape, input.dtype);
      output.allocateBuffer();
    }

    if (!this.pipelines.relu) {
      this.pipelines.relu = this.gpu.createComputePipeline({
        layout: 'auto',
        compute: {
          module: this.gpu.device.createShaderModule({
            code: `
              @group(0) @binding(0) var<storage, read> input: array<f32>;
              @group(0) @binding(1) var<storage, read_write> output: array<f32>;

              @compute @workgroup_size(256)
              fn main(@builtin(global_invocation_id) id: vec3<u32>) {
                let idx = id.x;
                if (idx >= arrayLength(&input)) { return; }
                output[idx] = max(0.0, input[idx]);
              }
            `
          }),
          entryPoint: 'main'
        }
      });
    }

    const bindGroup = this.gpu.createBindGroup(
      this.pipelines.relu.getBindGroupLayout(0),
      [
        { binding: 0, resource: { buffer: input.buffer } },
        { binding: 1, resource: { buffer: output.buffer } }
      ]
    );

    const encoder = this.gpu.createCommandEncoder('relu');
    const pass = encoder.beginComputePass();
    pass.setPipeline(this.pipelines.relu);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(input.size / 256));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    return output;
  }
}
