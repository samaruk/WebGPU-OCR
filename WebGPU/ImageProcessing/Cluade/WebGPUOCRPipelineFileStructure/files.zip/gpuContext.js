/**
 * GPU Context Manager
 * Handles WebGPU device initialization and resource management
 */

export class GPUContext {
  constructor() {
    this.adapter = null;
    this.device = null;
    this.queue = null;
    this.limits = null;
    this.features = new Set();
  }

  async initialize() {
    if (!navigator.gpu) {
      throw new Error('WebGPU not supported in this browser');
    }

    // Request adapter
    this.adapter = await navigator.gpu.requestAdapter({
      powerPreference: 'high-performance'
    });

    if (!this.adapter) {
      throw new Error('Failed to get GPU adapter');
    }

    // Get device
    const requiredFeatures = [];
    if (this.adapter.features.has('shader-f16')) {
      requiredFeatures.push('shader-f16');
      this.features.add('shader-f16');
    }
    if (this.adapter.features.has('timestamp-query')) {
      requiredFeatures.push('timestamp-query');
      this.features.add('timestamp-query');
    }

    this.device = await this.adapter.requestDevice({
      requiredFeatures,
      requiredLimits: {
        maxStorageBufferBindingSize: this.adapter.limits.maxStorageBufferBindingSize,
        maxBufferSize: this.adapter.limits.maxBufferSize,
        maxComputeWorkgroupStorageSize: this.adapter.limits.maxComputeWorkgroupStorageSize
      }
    });

    this.queue = this.device.queue;
    this.limits = this.device.limits;

    // Error handling
    this.device.addEventListener('uncapturederror', (event) => {
      console.error('WebGPU uncaptured error:', event.error);
    });

    console.log('GPU initialized:', {
      adapter: this.adapter.info,
      limits: this.limits,
      features: Array.from(this.features)
    });

    return this;
  }

  createBuffer(size, usage, label = '') {
    return this.device.createBuffer({
      size,
      usage,
      label
    });
  }

  createTexture(descriptor) {
    return this.device.createTexture(descriptor);
  }

  createBindGroup(layout, entries, label = '') {
    return this.device.createBindGroup({
      layout,
      entries,
      label
    });
  }

  createComputePipeline(descriptor) {
    return this.device.createComputePipeline(descriptor);
  }

  createRenderPipeline(descriptor) {
    return this.device.createRenderPipeline(descriptor);
  }

  createCommandEncoder(label = '') {
    return this.device.createCommandEncoder({ label });
  }

  submit(commandBuffers) {
    this.queue.submit(commandBuffers);
  }

  writeBuffer(buffer, data, offset = 0) {
    this.queue.writeBuffer(buffer, offset, data);
  }

  async readBuffer(buffer, offset = 0, size = buffer.size) {
    const stagingBuffer = this.createBuffer(
      size,
      GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ,
      'staging-read'
    );

    const encoder = this.createCommandEncoder('read-buffer');
    encoder.copyBufferToBuffer(buffer, offset, stagingBuffer, 0, size);
    this.submit([encoder.finish()]);

    await stagingBuffer.mapAsync(GPUMapMode.READ);
    const data = new Uint8Array(stagingBuffer.getMappedRange()).slice();
    stagingBuffer.unmap();
    stagingBuffer.destroy();

    return data;
  }

  async readTexture(texture) {
    const bytesPerRow = Math.ceil(texture.width * 4 / 256) * 256;
    const bufferSize = bytesPerRow * texture.height;

    const buffer = this.createBuffer(
      bufferSize,
      GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ,
      'texture-read'
    );

    const encoder = this.createCommandEncoder('read-texture');
    encoder.copyTextureToBuffer(
      { texture },
      { buffer, bytesPerRow },
      { width: texture.width, height: texture.height }
    );
    this.submit([encoder.finish()]);

    await buffer.mapAsync(GPUMapMode.READ);
    const data = new Uint8Array(buffer.getMappedRange()).slice();
    buffer.unmap();
    buffer.destroy();

    return data;
  }

  dispose() {
    if (this.device) {
      this.device.destroy();
    }
  }
}
