/**
 * Stage 9: Line Cropping
 * Extract individual text lines from regions
 */

export class LineCrop {
  constructor(gpuContext) {
    this.gpu = gpuContext;
    this.pipeline = null;
  }

  async initialize() {
    this.pipeline = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var inputTexture: texture_2d<f32>;
            @group(0) @binding(1) var<storage, read_write> projection: array<atomic<u32>>;

            @compute @workgroup_size(16, 16)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(inputTexture);
              if (id.x >= dims.x || id.y >= dims.y) { return; }

              let pixel = textureLoad(inputTexture, vec2<i32>(id.xy), 0).r;
              let value = u32(pixel * 1000.0);
              
              atomicAdd(&projection[id.y], value);
            }
          `
        }),
        entryPoint: 'main'
      }
    });
  }

  async extractLines(regions) {
    const lines = [];

    for (const region of regions) {
      const regionLines = await this.findLinesInRegion(region);
      lines.push(...regionLines);
    }

    return lines;
  }

  async findLinesInRegion(region) {
    const texture = region.image;
    const height = texture.height;

    // Compute horizontal projection
    const projectionBuffer = this.gpu.createBuffer(
      height * 4,
      GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC
    );

    const bindGroup = this.gpu.createBindGroup(
      this.pipeline.getBindGroupLayout(0),
      [
        { binding: 0, resource: texture.createView() },
        { binding: 1, resource: { buffer: projectionBuffer } }
      ]
    );

    const encoder = this.gpu.createCommandEncoder();
    const pass = encoder.beginComputePass();
    pass.setPipeline(this.pipeline);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(texture.width / 16), Math.ceil(height / 16));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    const projData = await this.gpu.readBuffer(projectionBuffer);
    const projection = new Uint32Array(projData.buffer);

    // Find line separators
    const threshold = projection.reduce((a, b) => a + b, 0) / height * 0.1;
    const separators = [];
    let inGap = false;

    for (let y = 0; y < height; y++) {
      if (projection[y] < threshold && !inGap) {
        inGap = true;
        separators.push(y);
      } else if (projection[y] >= threshold && inGap) {
        inGap = false;
        separators.push(y);
      }
    }

    // Extract line images
    const lines = [];
    for (let i = 0; i < separators.length - 1; i += 2) {
      const top = separators[i];
      const bottom = Math.min(separators[i + 1], height - 1);
      if (bottom - top > 5) { // Minimum line height
        lines.push({
          ...region,
          lineTop: top,
          lineBottom: bottom,
          lineHeight: bottom - top
        });
      }
    }

    projectionBuffer.destroy();
    return lines;
  }

  dispose() {}
}
