/**
 * Stage 10: Line Normalization
 * Normalize text line height and remove artifacts
 */

export class LineNormalize {
  constructor(gpuContext) {
    this.gpu = gpuContext;
    this.targetHeight = 32;
  }

  async initialize() {
    this.pipeline = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var inputTexture: texture_2d<f32>;
            @group(0) @binding(1) var outputTexture: texture_storage_2d<rgba8unorm, write>;
            @group(0) @binding(2) var<uniform> params: vec4<f32>; // scaleX, scaleY, offsetX, offsetY

            fn bicubic(t: f32) -> f32 {
              let a = -0.5;
              let abs_t = abs(t);
              if (abs_t <= 1.0) {
                return ((a + 2.0) * abs_t - (a + 3.0)) * abs_t * abs_t + 1.0;
              } else if (abs_t < 2.0) {
                return a * (((abs_t - 5.0) * abs_t + 8.0) * abs_t - 4.0);
              }
              return 0.0;
            }

            @compute @workgroup_size(8, 8)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(outputTexture);
              if (id.x >= dims.x || id.y >= dims.y) { return; }

              let srcX = f32(id.x) / params.x + params.z;
              let srcY = f32(id.y) / params.y + params.w;

              let srcDims = textureDimensions(inputTexture);
              if (srcX < 0.0 || srcX >= f32(srcDims.x) || srcY < 0.0 || srcY >= f32(srcDims.y)) {
                textureStore(outputTexture, vec2<i32>(id.xy), vec4<f32>(1.0));
                return;
              }

              // Bicubic interpolation
              let x0 = floor(srcX);
              let y0 = floor(srcY);
              let fx = srcX - x0;
              let fy = srcY - y0;

              var result = vec4<f32>(0.0);
              for (var j = -1; j <= 2; j++) {
                for (var i = -1; i <= 2; i++) {
                  let px = clamp(i32(x0) + i, 0, i32(srcDims.x) - 1);
                  let py = clamp(i32(y0) + j, 0, i32(srcDims.y) - 1);
                  let pixel = textureLoad(inputTexture, vec2<i32>(px, py), 0);
                  let weight = bicubic(f32(i) - fx) * bicubic(f32(j) - fy);
                  result += pixel * weight;
                }
              }

              textureStore(outputTexture, vec2<i32>(id.xy), clamp(result, vec4<f32>(0.0), vec4<f32>(1.0)));
            }
          `
        }),
        entryPoint: 'main'
      }
    });
  }

  async normalize(lines) {
    const normalized = [];

    for (const line of lines) {
      const norm = await this.normalizeLine(line);
      normalized.push(norm);
    }

    return normalized;
  }

  async normalizeLine(line) {
    const srcHeight = line.lineHeight || line.image.height;
    const srcWidth = line.image.width;
    
    const scale = this.targetHeight / srcHeight;
    const dstWidth = Math.round(srcWidth * scale);

    const paramsBuffer = this.gpu.createBuffer(16, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST);
    this.gpu.writeBuffer(paramsBuffer, new Float32Array([scale, scale, 0, line.lineTop || 0]));

    const outputTexture = this.gpu.createTexture({
      size: { width: dstWidth, height: this.targetHeight },
      format: 'rgba8unorm',
      usage: GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.TEXTURE_BINDING
    });

    const bindGroup = this.gpu.createBindGroup(
      this.pipeline.getBindGroupLayout(0),
      [
        { binding: 0, resource: line.image.createView() },
        { binding: 1, resource: outputTexture.createView() },
        { binding: 2, resource: { buffer: paramsBuffer } }
      ]
    );

    const encoder = this.gpu.createCommandEncoder();
    const pass = encoder.beginComputePass();
    pass.setPipeline(this.pipeline);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(dstWidth / 8), Math.ceil(this.targetHeight / 8));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    paramsBuffer.destroy();

    return { ...line, normalized: outputTexture, width: dstWidth, height: this.targetHeight };
  }

  dispose() {}
}
