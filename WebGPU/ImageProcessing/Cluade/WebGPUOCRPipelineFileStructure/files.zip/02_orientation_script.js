/**
 * Stage 2: Orientation and Script Detection
 * Detects document rotation and writing system (Latin, Arabic, CJK, etc.)
 */

export class OrientationScript {
  constructor(gpuContext) {
    this.gpu = gpuContext;
    this.pipelines = {};
  }

  async initialize() {
    // Edge detection for orientation
    this.pipelines.edges = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var inputTexture: texture_2d<f32>;
            @group(0) @binding(1) var outputTexture: texture_storage_2d<rgba8unorm, write>;

            @compute @workgroup_size(16, 16)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(inputTexture);
              if (id.x >= dims.x - 1 || id.y >= dims.y - 1 || id.x == 0 || id.y == 0) {
                return;
              }

              // Sobel operator for edge detection
              let tl = textureLoad(inputTexture, vec2<i32>(i32(id.x) - 1, i32(id.y) - 1), 0).r;
              let t  = textureLoad(inputTexture, vec2<i32>(i32(id.x), i32(id.y) - 1), 0).r;
              let tr = textureLoad(inputTexture, vec2<i32>(i32(id.x) + 1, i32(id.y) - 1), 0).r;
              let l  = textureLoad(inputTexture, vec2<i32>(i32(id.x) - 1, i32(id.y)), 0).r;
              let r  = textureLoad(inputTexture, vec2<i32>(i32(id.x) + 1, i32(id.y)), 0).r;
              let bl = textureLoad(inputTexture, vec2<i32>(i32(id.x) - 1, i32(id.y) + 1), 0).r;
              let b  = textureLoad(inputTexture, vec2<i32>(i32(id.x), i32(id.y) + 1), 0).r;
              let br = textureLoad(inputTexture, vec2<i32>(i32(id.x) + 1, i32(id.y) + 1), 0).r;

              let gx = -tl - 2.0 * l - bl + tr + 2.0 * r + br;
              let gy = -tl - 2.0 * t - tr + bl + 2.0 * b + br;
              
              let magnitude = sqrt(gx * gx + gy * gy);
              let angle = atan2(gy, gx);

              textureStore(outputTexture, vec2<i32>(id.xy), vec4<f32>(magnitude, angle, 0.0, 1.0));
            }
          `
        }),
        entryPoint: 'main'
      }
    });

    // Projection profile for orientation
    this.pipelines.projection = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var inputTexture: texture_2d<f32>;
            @group(0) @binding(1) var<storage, read_write> horizontalProj: array<atomic<u32>>;
            @group(0) @binding(2) var<storage, read_write> verticalProj: array<atomic<u32>>;

            @compute @workgroup_size(16, 16)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(inputTexture);
              if (id.x >= dims.x || id.y >= dims.y) { return; }

              let pixel = textureLoad(inputTexture, vec2<i32>(id.xy), 0).r;
              let value = u32(pixel * 1000.0);

              atomicAdd(&horizontalProj[id.y], value);
              atomicAdd(&verticalProj[id.x], value);
            }
          `
        }),
        entryPoint: 'main'
      }
    });

    // Hough transform for line detection
    this.pipelines.hough = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var edgeTexture: texture_2d<f32>;
            @group(0) @binding(1) var<storage, read_write> accumulator: array<atomic<u32>>;
            @group(0) @binding(2) var<uniform> params: vec4<u32>; // width, height, thetaBins, rhoBins

            @compute @workgroup_size(8, 8)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(edgeTexture);
              if (id.x >= dims.x || id.y >= dims.y) { return; }

              let edge = textureLoad(edgeTexture, vec2<i32>(id.xy), 0).r;
              if (edge < 0.1) { return; }

              let x = f32(id.x);
              let y = f32(id.y);
              let maxRho = sqrt(f32(dims.x * dims.x + dims.y * dims.y));
              
              let thetaBins = params.z;
              let rhoBins = params.w;

              // Vote in Hough space
              for (var t = 0u; t < thetaBins; t++) {
                let theta = f32(t) * 3.14159265 / f32(thetaBins);
                let rho = x * cos(theta) + y * sin(theta);
                let rhoNorm = (rho + maxRho) / (2.0 * maxRho);
                let rhoBin = u32(clamp(rhoNorm * f32(rhoBins), 0.0, f32(rhoBins - 1u)));
                
                let binIdx = t * rhoBins + rhoBin;
                atomicAdd(&accumulator[binIdx], 1u);
              }
            }
          `
        }),
        entryPoint: 'main'
      }
    });

    // Character shape analysis for script detection
    this.pipelines.shapeAnalysis = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var inputTexture: texture_2d<f32>;
            @group(0) @binding(1) var<storage, read_write> features: array<f32>;

            var<workgroup> aspectRatios: array<f32, 256>;
            var<workgroup> densities: array<f32, 256>;

            @compute @workgroup_size(16, 16)
            fn main(
              @builtin(global_invocation_id) id: vec3<u32>,
              @builtin(local_invocation_index) localIdx: u32
            ) {
              let dims = textureDimensions(inputTexture);
              
              // Divide image into blocks
              let blockSize = 32u;
              let blockX = id.x * blockSize;
              let blockY = id.y * blockSize;
              
              if (blockX >= dims.x || blockY >= dims.y) { return; }

              // Analyze block characteristics
              var pixelCount = 0.0;
              var width = 0.0;
              var height = 0.0;
              var minX = f32(blockSize);
              var maxX = 0.0;
              var minY = f32(blockSize);
              var maxY = 0.0;

              for (var dy = 0u; dy < blockSize; dy++) {
                for (var dx = 0u; dx < blockSize; dx++) {
                  let px = blockX + dx;
                  let py = blockY + dy;
                  if (px < dims.x && py < dims.y) {
                    let pixel = textureLoad(inputTexture, vec2<i32>(i32(px), i32(py)), 0).r;
                    if (pixel > 0.5) {
                      pixelCount += 1.0;
                      minX = min(minX, f32(dx));
                      maxX = max(maxX, f32(dx));
                      minY = min(minY, f32(dy));
                      maxY = max(maxY, f32(dy));
                    }
                  }
                }
              }

              width = maxX - minX;
              height = maxY - minY;
              let aspectRatio = select(1.0, width / height, height > 0.0);
              let density = pixelCount / f32(blockSize * blockSize);

              aspectRatios[localIdx] = aspectRatio;
              densities[localIdx] = density;

              workgroupBarrier();

              if (localIdx == 0u) {
                var avgAspect = 0.0;
                var avgDensity = 0.0;
                for (var i = 0u; i < 256u; i++) {
                  avgAspect += aspectRatios[i];
                  avgDensity += densities[i];
                }
                avgAspect /= 256.0;
                avgDensity /= 256.0;

                let workgroupId = id.y * (dims.x / blockSize / 16u) + id.x;
                features[workgroupId * 2u] = avgAspect;
                features[workgroupId * 2u + 1u] = avgDensity;
              }
            }
          `
        }),
        entryPoint: 'main'
      }
    });
  }

  async detect(imageData) {
    const { width, height } = imageData;

    // Create input texture
    const texture = this.gpu.createTexture({
      size: { width, height },
      format: 'rgba8unorm',
      usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST
    });

    this.gpu.queue.writeTexture(
      { texture },
      imageData.data,
      { bytesPerRow: width * 4 },
      { width, height }
    );

    // Detect orientation
    const angle = await this.detectOrientation(texture, width, height);
    
    // Detect script type
    const scriptType = await this.detectScript(texture, width, height);

    texture.destroy();

    return {
      angle,
      scriptType,
      confidence: 0.85 // Placeholder
    };
  }

  async detectOrientation(texture, width, height) {
    // Compute edge map
    const edgeTexture = this.gpu.createTexture({
      size: { width, height },
      format: 'rgba8unorm',
      usage: GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.TEXTURE_BINDING
    });

    let bindGroup = this.gpu.createBindGroup(
      this.pipelines.edges.getBindGroupLayout(0),
      [
        { binding: 0, resource: texture.createView() },
        { binding: 1, resource: edgeTexture.createView() }
      ]
    );

    let encoder = this.gpu.createCommandEncoder();
    let pass = encoder.beginComputePass();
    pass.setPipeline(this.pipelines.edges);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(width / 16), Math.ceil(height / 16));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    // Hough transform for dominant angles
    const thetaBins = 180;
    const rhoBins = Math.ceil(Math.sqrt(width * width + height * height));
    const accumulatorSize = thetaBins * rhoBins * 4;
    
    const accumulator = this.gpu.createBuffer(
      accumulatorSize,
      GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC
    );

    const paramsBuffer = this.gpu.createBuffer(
      16,
      GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
    );
    this.gpu.writeBuffer(paramsBuffer, new Uint32Array([width, height, thetaBins, rhoBins]));

    bindGroup = this.gpu.createBindGroup(
      this.pipelines.hough.getBindGroupLayout(0),
      [
        { binding: 0, resource: edgeTexture.createView() },
        { binding: 1, resource: { buffer: accumulator } },
        { binding: 2, resource: { buffer: paramsBuffer } }
      ]
    );

    encoder = this.gpu.createCommandEncoder();
    pass = encoder.beginComputePass();
    pass.setPipeline(this.pipelines.hough);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(width / 8), Math.ceil(height / 8));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    // Read accumulator and find dominant angle
    const accData = await this.gpu.readBuffer(accumulator);
    const accArray = new Uint32Array(accData.buffer);

    let maxVotes = 0;
    let dominantTheta = 0;

    for (let t = 0; t < thetaBins; t++) {
      let thetaVotes = 0;
      for (let r = 0; r < rhoBins; r++) {
        thetaVotes += accArray[t * rhoBins + r];
      }
      if (thetaVotes > maxVotes) {
        maxVotes = thetaVotes;
        dominantTheta = t;
      }
    }

    edgeTexture.destroy();
    accumulator.destroy();
    paramsBuffer.destroy();

    // Convert to angle
    const angle = (dominantTheta * 180.0 / thetaBins);
    
    // Snap to common rotations (0, 90, 180, 270)
    if (Math.abs(angle) < 5 || Math.abs(angle - 180) < 5) return 0;
    if (Math.abs(angle - 90) < 5) return 90;
    if (Math.abs(angle - 270) < 5 || Math.abs(angle + 90) < 5) return 270;
    
    return Math.round(angle);
  }

  async detectScript(texture, width, height) {
    const numBlocks = Math.ceil(width / 32) * Math.ceil(height / 32);
    const featuresBuffer = this.gpu.createBuffer(
      numBlocks * 16 * 2 * 4, // aspect ratio + density per block
      GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC
    );

    const bindGroup = this.gpu.createBindGroup(
      this.pipelines.shapeAnalysis.getBindGroupLayout(0),
      [
        { binding: 0, resource: texture.createView() },
        { binding: 1, resource: { buffer: featuresBuffer } }
      ]
    );

    const encoder = this.gpu.createCommandEncoder();
    const pass = encoder.beginComputePass();
    pass.setPipeline(this.pipelines.shapeAnalysis);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(
      Math.ceil(width / 32 / 16), 
      Math.ceil(height / 32 / 16)
    );
    pass.end();
    this.gpu.submit([encoder.finish()]);

    const featuresData = await this.gpu.readBuffer(featuresBuffer);
    const features = new Float32Array(featuresData.buffer);

    // Analyze features to determine script
    let avgAspectRatio = 0;
    let avgDensity = 0;
    let count = 0;

    for (let i = 0; i < features.length; i += 2) {
      if (features[i] > 0) {
        avgAspectRatio += features[i];
        avgDensity += features[i + 1];
        count++;
      }
    }

    if (count > 0) {
      avgAspectRatio /= count;
      avgDensity /= count;
    }

    featuresBuffer.destroy();

    // Simple heuristics for script classification
    // CJK: more square (aspect ~1.0), denser
    // Latin: wider (aspect ~2.0), medium density
    // Arabic: very wide (aspect ~3.0), flowing
    
    if (avgAspectRatio < 1.3 && avgDensity > 0.4) {
      return 'CJK'; // Chinese, Japanese, Korean
    } else if (avgAspectRatio > 2.5) {
      return 'Arabic';
    } else {
      return 'Latin';
    }
  }

  dispose() {
    // Managed by GPU context
  }
}
