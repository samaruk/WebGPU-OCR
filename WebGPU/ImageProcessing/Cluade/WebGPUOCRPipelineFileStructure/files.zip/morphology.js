/**
 * Morphological Operations
 * Erosion, dilation, opening, closing
 */

export class Morphology {
  constructor(gpuContext) {
    this.gpu = gpuContext;
  }

  async initialize() {
    this.pipeline = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var inputTexture: texture_2d<f32>;
            @group(0) @binding(1) var outputTexture: texture_storage_2d<r32float, write>;
            @group(0) @binding(2) var<uniform> params: vec4<u32>; // operation, kernelSize

            @compute @workgroup_size(8, 8)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(inputTexture);
              if (id.x >= dims.x || id.y >= dims.y) { return; }

              let operation = params.x; // 0=dilate, 1=erode
              let radius = i32(params.y);

              var result = 0.0;
              if (operation == 0u) {
                // Dilation: max in neighborhood
                for (var dy = -radius; dy <= radius; dy++) {
                  for (var dx = -radius; dx <= radius; dx++) {
                    let px = clamp(i32(id.x) + dx, 0, i32(dims.x) - 1);
                    let py = clamp(i32(id.y) + dy, 0, i32(dims.y) - 1);
                    let value = textureLoad(inputTexture, vec2<i32>(px, py), 0).r;
                    result = max(result, value);
                  }
                }
              } else {
                // Erosion: min in neighborhood
                result = 1.0;
                for (var dy = -radius; dy <= radius; dy++) {
                  for (var dx = -radius; dx <= radius; dx++) {
                    let px = clamp(i32(id.x) + dx, 0, i32(dims.x) - 1);
                    let py = clamp(i32(id.y) + dy, 0, i32(dims.y) - 1);
                    let value = textureLoad(inputTexture, vec2<i32>(px, py), 0).r;
                    result = min(result, value);
                  }
                }
              }

              textureStore(outputTexture, vec2<i32>(id.xy), vec4<f32>(result));
            }
          `
        }),
        entryPoint: 'main'
      }
    });
  }

  async dilate(texture, kernelSize = 3) {
    return this.morph(texture, 0, kernelSize);
  }

  async erode(texture, kernelSize = 3) {
    return this.morph(texture, 1, kernelSize);
  }

  async morph(inputTexture, operation, kernelSize) {
    const outputTexture = this.gpu.createTexture({
      size: { width: inputTexture.width, height: inputTexture.height },
      format: 'r32float',
      usage: GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.TEXTURE_BINDING
    });

    const paramsBuffer = this.gpu.createBuffer(16, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST);
    this.gpu.writeBuffer(paramsBuffer, new Uint32Array([operation, Math.floor(kernelSize / 2)]));

    const bindGroup = this.gpu.createBindGroup(
      this.pipeline.getBindGroupLayout(0),
      [
        { binding: 0, resource: inputTexture.createView() },
        { binding: 1, resource: outputTexture.createView() },
        { binding: 2, resource: { buffer: paramsBuffer } }
      ]
    );

    const encoder = this.gpu.createCommandEncoder();
    const pass = encoder.beginComputePass();
    pass.setPipeline(this.pipeline);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(
      Math.ceil(inputTexture.width / 8),
      Math.ceil(inputTexture.height / 8)
    );
    pass.end();
    this.gpu.submit([encoder.finish()]);

    paramsBuffer.destroy();
    return outputTexture;
  }

  dispose() {}
}
