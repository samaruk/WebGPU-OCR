/**
 * Stage 1: Image Quality Assessment (IQA)
 * Evaluates image quality metrics: sharpness, noise, contrast, brightness
 */

export class IQA {
  constructor(gpuContext) {
    this.gpu = gpuContext;
    this.pipelines = {};
  }

  async initialize() {
    // Sharpness detection pipeline (Laplacian variance)
    this.pipelines.sharpness = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var inputTexture: texture_2d<f32>;
            @group(0) @binding(1) var<storage, read_write> results: array<f32>;

            @compute @workgroup_size(16, 16)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(inputTexture);
              if (id.x >= dims.x - 1 || id.y >= dims.y - 1 || id.x == 0 || id.y == 0) { 
                return; 
              }

              // Laplacian kernel
              let center = textureLoad(inputTexture, vec2<i32>(id.xy), 0).r;
              let top = textureLoad(inputTexture, vec2<i32>(i32(id.x), i32(id.y) - 1), 0).r;
              let bottom = textureLoad(inputTexture, vec2<i32>(i32(id.x), i32(id.y) + 1), 0).r;
              let left = textureLoad(inputTexture, vec2<i32>(i32(id.x) - 1, i32(id.y)), 0).r;
              let right = textureLoad(inputTexture, vec2<i32>(i32(id.x) + 1, i32(id.y)), 0).r;

              let laplacian = abs(-4.0 * center + top + bottom + left + right);
              
              let idx = id.y * dims.x + id.x;
              results[idx] = laplacian;
            }
          `
        }),
        entryPoint: 'main'
      }
    });

    // Noise estimation pipeline
    this.pipelines.noise = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var inputTexture: texture_2d<f32>;
            @group(0) @binding(1) var<storage, read_write> variance: array<f32>;

            var<workgroup> localPixels: array<f32, 256>;

            @compute @workgroup_size(16, 16)
            fn main(
              @builtin(global_invocation_id) id: vec3<u32>,
              @builtin(local_invocation_index) localIdx: u32
            ) {
              let dims = textureDimensions(inputTexture);
              
              if (id.x < dims.x && id.y < dims.y) {
                let pixel = textureLoad(inputTexture, vec2<i32>(id.xy), 0);
                let gray = 0.299 * pixel.r + 0.587 * pixel.g + 0.114 * pixel.b;
                localPixels[localIdx] = gray;
              } else {
                localPixels[localIdx] = 0.0;
              }

              workgroupBarrier();

              // Compute local variance
              if (localIdx == 0u) {
                var mean = 0.0;
                for (var i = 0u; i < 256u; i++) {
                  mean += localPixels[i];
                }
                mean /= 256.0;

                var var_sum = 0.0;
                for (var i = 0u; i < 256u; i++) {
                  let diff = localPixels[i] - mean;
                  var_sum += diff * diff;
                }
                
                let workgroupId = id.y / 16u * (dims.x / 16u) + id.x / 16u;
                variance[workgroupId] = var_sum / 256.0;
              }
            }
          `
        }),
        entryPoint: 'main'
      }
    });

    // Contrast assessment
    this.pipelines.contrast = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var inputTexture: texture_2d<f32>;
            @group(0) @binding(1) var<storage, read_write> histogram: array<atomic<u32>, 256>;

            @compute @workgroup_size(16, 16)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(inputTexture);
              if (id.x >= dims.x || id.y >= dims.y) { return; }

              let pixel = textureLoad(inputTexture, vec2<i32>(id.xy), 0);
              let gray = 0.299 * pixel.r + 0.587 * pixel.g + 0.114 * pixel.b;
              let bin = u32(clamp(gray * 255.0, 0.0, 255.0));
              
              atomicAdd(&histogram[bin], 1u);
            }
          `
        }),
        entryPoint: 'main'
      }
    });

    // Reduction pipeline for statistics
    this.pipelines.reduce = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var<storage, read> input: array<f32>;
            @group(0) @binding(1) var<storage, read_write> output: array<f32>;
            @group(0) @binding(2) var<uniform> size: u32;

            var<workgroup> sharedData: array<f32, 256>;

            @compute @workgroup_size(256)
            fn main(
              @builtin(global_invocation_id) globalId: vec3<u32>,
              @builtin(local_invocation_id) localId: vec3<u32>
            ) {
              let tid = localId.x;
              let idx = globalId.x;

              // Load data
              sharedData[tid] = select(0.0, input[idx], idx < size);
              workgroupBarrier();

              // Parallel reduction
              for (var s = 128u; s > 0u; s >>= 1u) {
                if (tid < s) {
                  sharedData[tid] += sharedData[tid + s];
                }
                workgroupBarrier();
              }

              if (tid == 0u) {
                output[globalId.x / 256u] = sharedData[0];
              }
            }
          `
        }),
        entryPoint: 'main'
      }
    });
  }

  async assess(imageData) {
    const { width, height } = imageData;

    // Create input texture
    const texture = this.gpu.createTexture({
      size: { width, height },
      format: 'rgba8unorm',
      usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST
    });

    this.gpu.queue.writeTexture(
      { texture },
      imageData.data,
      { bytesPerRow: width * 4 },
      { width, height }
    );

    // Assess sharpness
    const sharpness = await this.assessSharpness(texture, width, height);
    
    // Assess noise
    const noise = await this.assessNoise(texture, width, height);
    
    // Assess contrast
    const contrast = await this.assessContrast(texture, width, height);
    
    // Assess brightness
    const brightness = await this.assessBrightness(texture, width, height);

    texture.destroy();

    // Combine metrics
    const overall = this.computeOverallScore(sharpness, noise, contrast, brightness);

    return {
      sharpness,
      noise,
      contrast,
      brightness,
      overall,
      acceptable: overall > 0.4
    };
  }

  async assessSharpness(texture, width, height) {
    const resultsBuffer = this.gpu.createBuffer(
      width * height * 4,
      GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC
    );

    const bindGroup = this.gpu.createBindGroup(
      this.pipelines.sharpness.getBindGroupLayout(0),
      [
        { binding: 0, resource: texture.createView() },
        { binding: 1, resource: { buffer: resultsBuffer } }
      ]
    );

    const encoder = this.gpu.createCommandEncoder();
    const pass = encoder.beginComputePass();
    pass.setPipeline(this.pipelines.sharpness);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(width / 16), Math.ceil(height / 16));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    // Read results and compute variance
    const data = await this.gpu.readBuffer(resultsBuffer);
    const float32Data = new Float32Array(data.buffer);
    
    let sum = 0;
    let count = 0;
    for (let i = 0; i < float32Data.length; i++) {
      if (float32Data[i] > 0) {
        sum += float32Data[i];
        count++;
      }
    }
    
    const variance = count > 0 ? sum / count : 0;
    resultsBuffer.destroy();

    // Normalize to 0-1 score (higher variance = sharper)
    return Math.min(variance / 100.0, 1.0);
  }

  async assessNoise(texture, width, height) {
    const numWorkgroups = Math.ceil(width / 16) * Math.ceil(height / 16);
    const varianceBuffer = this.gpu.createBuffer(
      numWorkgroups * 4,
      GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC
    );

    const bindGroup = this.gpu.createBindGroup(
      this.pipelines.noise.getBindGroupLayout(0),
      [
        { binding: 0, resource: texture.createView() },
        { binding: 1, resource: { buffer: varianceBuffer } }
      ]
    );

    const encoder = this.gpu.createCommandEncoder();
    const pass = encoder.beginComputePass();
    pass.setPipeline(this.pipelines.noise);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(width / 16), Math.ceil(height / 16));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    const data = await this.gpu.readBuffer(varianceBuffer);
    const variances = new Float32Array(data.buffer);
    
    let avgVariance = 0;
    for (let i = 0; i < variances.length; i++) {
      avgVariance += variances[i];
    }
    avgVariance /= variances.length;

    varianceBuffer.destroy();

    // Lower variance = less noise = higher score
    return Math.max(0, 1.0 - avgVariance / 0.1);
  }

  async assessContrast(texture, width, height) {
    const histogramBuffer = this.gpu.createBuffer(
      256 * 4,
      GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC
    );

    const bindGroup = this.gpu.createBindGroup(
      this.pipelines.contrast.getBindGroupLayout(0),
      [
        { binding: 0, resource: texture.createView() },
        { binding: 1, resource: { buffer: histogramBuffer } }
      ]
    );

    const encoder = this.gpu.createCommandEncoder();
    const pass = encoder.beginComputePass();
    pass.setPipeline(this.pipelines.contrast);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(width / 16), Math.ceil(height / 16));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    const data = await this.gpu.readBuffer(histogramBuffer);
    const histogram = new Uint32Array(data.buffer);

    // Compute contrast using histogram spread
    let min = 0, max = 255;
    const totalPixels = width * height;
    const threshold = totalPixels * 0.01; // 1% threshold

    let cumSum = 0;
    for (let i = 0; i < 256; i++) {
      cumSum += histogram[i];
      if (cumSum > threshold) {
        min = i;
        break;
      }
    }

    cumSum = 0;
    for (let i = 255; i >= 0; i--) {
      cumSum += histogram[i];
      if (cumSum > threshold) {
        max = i;
        break;
      }
    }

    histogramBuffer.destroy();

    const contrastRange = max - min;
    return contrastRange / 255.0; // Normalized contrast score
  }

  async assessBrightness(texture, width, height) {
    // Use existing histogram from contrast
    // Compute mean brightness
    const histogramBuffer = this.gpu.createBuffer(
      256 * 4,
      GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC
    );

    const bindGroup = this.gpu.createBindGroup(
      this.pipelines.contrast.getBindGroupLayout(0),
      [
        { binding: 0, resource: texture.createView() },
        { binding: 1, resource: { buffer: histogramBuffer } }
      ]
    );

    const encoder = this.gpu.createCommandEncoder();
    const pass = encoder.beginComputePass();
    pass.setPipeline(this.pipelines.contrast);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(width / 16), Math.ceil(height / 16));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    const data = await this.gpu.readBuffer(histogramBuffer);
    const histogram = new Uint32Array(data.buffer);

    let meanBrightness = 0;
    let totalPixels = 0;
    for (let i = 0; i < 256; i++) {
      meanBrightness += i * histogram[i];
      totalPixels += histogram[i];
    }
    meanBrightness /= totalPixels;

    histogramBuffer.destroy();

    // Optimal brightness around 127, penalize extremes
    const optimalness = 1.0 - Math.abs(meanBrightness - 127) / 127;
    return optimalness;
  }

  computeOverallScore(sharpness, noise, contrast, brightness) {
    // Weighted combination
    return 0.35 * sharpness + 
           0.25 * noise + 
           0.25 * contrast + 
           0.15 * brightness;
  }

  dispose() {
    // Pipelines are managed by GPU context
  }
}
