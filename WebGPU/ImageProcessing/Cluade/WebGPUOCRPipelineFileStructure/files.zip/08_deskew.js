/**
 * Stage 8: Deskew
 * Correct skew/rotation of individual text regions
 */

export class Deskew {
  constructor(gpuContext) {
    this.gpu = gpuContext;
    this.pipeline = null;
  }

  async initialize() {
    this.pipeline = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var inputTexture: texture_2d<f32>;
            @group(0) @binding(1) var outputTexture: texture_storage_2d<rgba8unorm, write>;
            @group(0) @binding(2) var<uniform> transform: mat3x3<f32>;

            @compute @workgroup_size(8, 8)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(outputTexture);
              if (id.x >= dims.x || id.y >= dims.y) { return; }

              // Apply affine transform
              let pos = vec3<f32>(f32(id.x), f32(id.y), 1.0);
              let srcPos = transform * pos;
              
              let srcX = i32(srcPos.x);
              let srcY = i32(srcPos.y);
              
              let srcDims = textureDimensions(inputTexture);
              if (srcX >= 0 && srcX < i32(srcDims.x) && srcY >= 0 && srcY < i32(srcDims.y)) {
                let pixel = textureLoad(inputTexture, vec2<i32>(srcX, srcY), 0);
                textureStore(outputTexture, vec2<i32>(id.xy), pixel);
              }
            }
          `
        }),
        entryPoint: 'main'
      }
    });
  }

  async processRegions(image, regions) {
    const deskewed = [];
    
    for (const region of regions) {
      const angle = this.detectSkewAngle(region.polygon);
      const rectified = await this.deskewRegion(image, region, angle);
      deskewed.push({ ...region, image: rectified, skewAngle: angle });
    }

    return deskewed;
  }

  detectSkewAngle(polygon) {
    // Fit minimum area rectangle
    let minArea = Infinity;
    let bestAngle = 0;

    for (let angle = -45; angle <= 45; angle += 1) {
      const rad = angle * Math.PI / 180;
      const cos = Math.cos(rad);
      const sin = Math.sin(rad);

      let minX = Infinity, maxX = -Infinity;
      let minY = Infinity, maxY = -Infinity;

      for (const p of polygon) {
        const rx = p.x * cos - p.y * sin;
        const ry = p.x * sin + p.y * cos;
        minX = Math.min(minX, rx);
        maxX = Math.max(maxX, rx);
        minY = Math.min(minY, ry);
        maxY = Math.max(maxY, ry);
      }

      const area = (maxX - minX) * (maxY - minY);
      if (area < minArea) {
        minArea = area;
        bestAngle = angle;
      }
    }

    return bestAngle;
  }

  async deskewRegion(image, region, angle) {
    // Create rotation matrix
    const rad = -angle * Math.PI / 180;
    const cos = Math.cos(rad);
    const sin = Math.sin(rad);

    // Compute bounding box
    const points = region.polygon;
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const p of points) {
      minX = Math.min(minX, p.x);
      maxX = Math.max(maxX, p.x);
      minY = Math.min(minY, p.y);
      maxY = Math.max(maxY, p.y);
    }

    const cx = (minX + maxX) / 2;
    const cy = (minY + maxY) / 2;

    // Transform matrix
    const transform = new Float32Array([
      cos, -sin, cx - cos * cx + sin * cy,
      sin, cos, cy - sin * cx - cos * cy,
      0, 0, 1
    ]);

    const transformBuffer = this.gpu.createBuffer(
      48, GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
    );
    this.gpu.writeBuffer(transformBuffer, transform);

    const outputWidth = Math.ceil(maxX - minX);
    const outputHeight = Math.ceil(maxY - minY);

    const outputTexture = this.gpu.createTexture({
      size: { width: outputWidth, height: outputHeight },
      format: 'rgba8unorm',
      usage: GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.COPY_SRC
    });

    const bindGroup = this.gpu.createBindGroup(
      this.pipeline.getBindGroupLayout(0),
      [
        { binding: 0, resource: image.createView() },
        { binding: 1, resource: outputTexture.createView() },
        { binding: 2, resource: { buffer: transformBuffer } }
      ]
    );

    const encoder = this.gpu.createCommandEncoder();
    const pass = encoder.beginComputePass();
    pass.setPipeline(this.pipeline);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(outputWidth / 8), Math.ceil(outputHeight / 8));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    transformBuffer.destroy();
    return outputTexture;
  }

  dispose() {}
}
