/**
 * Layout Engine
 * Analyzes document layout and reading order
 */

export class LayoutEngine {
  constructor(gpuContext) {
    this.gpu = gpuContext;
  }

  async initialize() {}

  async analyze(results, width, height) {
    const regions = results.regions;

    // Classify region types
    const classified = this.classifyRegions(regions);

    // Detect columns
    const columns = this.detectColumns(classified, width);

    // Establish reading order
    const ordered = this.establishReadingOrder(classified, columns);

    // Detect paragraphs
    const paragraphs = this.detectParagraphs(ordered);

    return {
      regions: ordered,
      columns,
      paragraphs,
      readingOrder: ordered.map((r, i) => ({ ...r, order: i }))
    };
  }

  classifyRegions(regions) {
    return regions.map(region => {
      const type = this.inferRegionType(region);
      return { ...region, type };
    });
  }

  inferRegionType(region) {
    if (!region.polygon) return 'text';

    const poly = region.polygon;
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const p of poly) {
      minX = Math.min(minX, p.x);
      maxX = Math.max(maxX, p.x);
      minY = Math.min(minY, p.y);
      maxY = Math.max(maxY, p.y);
    }

    const width = maxX - minX;
    const height = maxY - minY;
    const aspectRatio = width / height;

    // Simple heuristics
    if (aspectRatio > 3) return 'title';
    if (aspectRatio < 1.5 && width < 100) return 'number';
    return 'text';
  }

  detectColumns(regions, pageWidth) {
    if (regions.length === 0) return [{ x: 0, width: pageWidth }];

    // X-projection to find column gaps
    const projection = new Array(Math.ceil(pageWidth)).fill(0);

    for (const region of regions) {
      if (!region.polygon) continue;
      
      let minX = Infinity, maxX = -Infinity;
      for (const p of region.polygon) {
        minX = Math.min(minX, p.x);
        maxX = Math.max(maxX, p.x);
      }

      for (let x = Math.floor(minX); x < Math.ceil(maxX) && x < projection.length; x++) {
        projection[x]++;
      }
    }

    // Find gaps
    const gaps = [];
    const threshold = regions.length * 0.1;
    let inGap = false;
    let gapStart = 0;

    for (let x = 0; x < projection.length; x++) {
      if (projection[x] < threshold && !inGap) {
        inGap = true;
        gapStart = x;
      } else if (projection[x] >= threshold && inGap) {
        if (x - gapStart > 20) { // Minimum gap width
          gaps.push({ x: gapStart, width: x - gapStart });
        }
        inGap = false;
      }
    }

    // Convert gaps to columns
    const columns = [];
    let prevEnd = 0;

    for (const gap of gaps) {
      columns.push({ x: prevEnd, width: gap.x - prevEnd });
      prevEnd = gap.x + gap.width;
    }
    columns.push({ x: prevEnd, width: pageWidth - prevEnd });

    return columns.filter(c => c.width > 50);
  }

  establishReadingOrder(regions, columns) {
    // Assign regions to columns
    const columnRegions = columns.map(() => []);

    for (const region of regions) {
      if (!region.polygon) continue;

      const centroid = this.getCentroid(region.polygon);
      let assignedColumn = 0;

      for (let i = 0; i < columns.length; i++) {
        const col = columns[i];
        if (centroid.x >= col.x && centroid.x < col.x + col.width) {
          assignedColumn = i;
          break;
        }
      }

      columnRegions[assignedColumn].push(region);
    }

    // Sort within each column by Y position
    for (const colRegs of columnRegions) {
      colRegs.sort((a, b) => {
        const aY = this.getCentroid(a.polygon).y;
        const bY = this.getCentroid(b.polygon).y;
        return aY - bY;
      });
    }

    // Flatten in reading order (left-to-right, top-to-bottom)
    return columnRegions.flat();
  }

  detectParagraphs(orderedRegions) {
    const paragraphs = [];
    let currentParagraph = [];
    let prevBottom = 0;

    for (const region of orderedRegions) {
      if (!region.polygon) continue;

      const bounds = this.getBounds(region.polygon);
      const gap = bounds.minY - prevBottom;

      // New paragraph if gap is large
      if (gap > 20 && currentParagraph.length > 0) {
        paragraphs.push([...currentParagraph]);
        currentParagraph = [];
      }

      currentParagraph.push(region);
      prevBottom = bounds.maxY;
    }

    if (currentParagraph.length > 0) {
      paragraphs.push(currentParagraph);
    }

    return paragraphs;
  }

  getCentroid(polygon) {
    let x = 0, y = 0;
    for (const p of polygon) {
      x += p.x;
      y += p.y;
    }
    return { x: x / polygon.length, y: y / polygon.length };
  }

  getBounds(polygon) {
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const p of polygon) {
      minX = Math.min(minX, p.x);
      maxX = Math.max(maxX, p.x);
      minY = Math.min(minY, p.y);
      maxY = Math.max(maxY, p.y);
    }
    return { minX, maxX, minY, maxY };
  }

  dispose() {}
}
