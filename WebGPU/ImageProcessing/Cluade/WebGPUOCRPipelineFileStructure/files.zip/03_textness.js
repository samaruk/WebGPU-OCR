/**
 * Stage 3: Textness Map Generation
 * Computes probability map of text vs non-text regions
 */

export class Textness {
  constructor(gpuContext) {
    this.gpu = gpuContext;
    this.pipelines = {};
  }

  async initialize() {
    // Stroke Width Transform (SWT) for textness
    this.pipelines.swt = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var edgeTexture: texture_2d<f32>;
            @group(0) @binding(1) var gradientTexture: texture_2d<f32>;
            @group(0) @binding(2) var swtTexture: texture_storage_2d<r32float, write>;

            @compute @workgroup_size(8, 8)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(edgeTexture);
              if (id.x >= dims.x || id.y >= dims.y) { return; }

              let edge = textureLoad(edgeTexture, vec2<i32>(id.xy), 0).r;
              if (edge < 0.1) {
                textureStore(swtTexture, vec2<i32>(id.xy), vec4<f32>(-1.0));
                return;
              }

              let gradient = textureLoad(gradientTexture, vec2<i32>(id.xy), 0);
              let dx = gradient.r;
              let dy = gradient.g;
              let magnitude = sqrt(dx * dx + dy * dy);

              if (magnitude < 0.01) {
                textureStore(swtTexture, vec2<i32>(id.xy), vec4<f32>(-1.0));
                return;
              }

              // Normalize gradient direction
              let dirX = dx / magnitude;
              let dirY = dy / magnitude;

              // Ray casting along gradient direction
              var minStrokeWidth = 1000.0;
              var foundStroke = false;

              for (var step = 1.0; step < 50.0; step += 1.0) {
                let rayX = f32(id.x) + dirX * step;
                let rayY = f32(id.y) + dirY * step;

                if (rayX < 0.0 || rayX >= f32(dims.x) || rayY < 0.0 || rayY >= f32(dims.y)) {
                  break;
                }

                let rayEdge = textureLoad(edgeTexture, vec2<i32>(i32(rayX), i32(rayY)), 0).r;
                if (rayEdge > 0.1) {
                  let rayGradient = textureLoad(gradientTexture, vec2<i32>(i32(rayX), i32(rayY)), 0);
                  let rayDx = rayGradient.r;
                  let rayDy = rayGradient.g;
                  let rayMag = sqrt(rayDx * rayDx + rayDy * rayDy);

                  if (rayMag > 0.01) {
                    let rayDirX = rayDx / rayMag;
                    let rayDirY = rayDy / rayMag;
                    
                    // Check if gradients are opposite (stroke boundary)
                    let dotProduct = dirX * rayDirX + dirY * rayDirY;
                    if (dotProduct < -0.5) {
                      minStrokeWidth = step;
                      foundStroke = true;
                      break;
                    }
                  }
                }
              }

              if (foundStroke) {
                textureStore(swtTexture, vec2<i32>(id.xy), vec4<f32>(minStrokeWidth));
              } else {
                textureStore(swtTexture, vec2<i32>(id.xy), vec4<f32>(-1.0));
              }
            }
          `
        }),
        entryPoint: 'main'
      }
    });

    // Local binary pattern for texture analysis
    this.pipelines.lbp = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var inputTexture: texture_2d<f32>;
            @group(0) @binding(1) var lbpTexture: texture_storage_2d<r8uint, write>;

            @compute @workgroup_size(8, 8)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(inputTexture);
              if (id.x >= dims.x - 1 || id.y >= dims.y - 1 || id.x == 0 || id.y == 0) {
                return;
              }

              let center = textureLoad(inputTexture, vec2<i32>(id.xy), 0).r;
              
              // 8-neighbor LBP
              var lbpCode = 0u;
              
              let p0 = textureLoad(inputTexture, vec2<i32>(i32(id.x) - 1, i32(id.y) - 1), 0).r;
              let p1 = textureLoad(inputTexture, vec2<i32>(i32(id.x), i32(id.y) - 1), 0).r;
              let p2 = textureLoad(inputTexture, vec2<i32>(i32(id.x) + 1, i32(id.y) - 1), 0).r;
              let p3 = textureLoad(inputTexture, vec2<i32>(i32(id.x) + 1, i32(id.y)), 0).r;
              let p4 = textureLoad(inputTexture, vec2<i32>(i32(id.x) + 1, i32(id.y) + 1), 0).r;
              let p5 = textureLoad(inputTexture, vec2<i32>(i32(id.x), i32(id.y) + 1), 0).r;
              let p6 = textureLoad(inputTexture, vec2<i32>(i32(id.x) - 1, i32(id.y) + 1), 0).r;
              let p7 = textureLoad(inputTexture, vec2<i32>(i32(id.x) - 1, i32(id.y)), 0).r;

              lbpCode |= select(0u, 1u, p0 >= center) << 0u;
              lbpCode |= select(0u, 1u, p1 >= center) << 1u;
              lbpCode |= select(0u, 1u, p2 >= center) << 2u;
              lbpCode |= select(0u, 1u, p3 >= center) << 3u;
              lbpCode |= select(0u, 1u, p4 >= center) << 4u;
              lbpCode |= select(0u, 1u, p5 >= center) << 5u;
              lbpCode |= select(0u, 1u, p6 >= center) << 6u;
              lbpCode |= select(0u, 1u, p7 >= center) << 7u;

              textureStore(lbpTexture, vec2<i32>(id.xy), vec4<u32>(lbpCode, 0u, 0u, 0u));
            }
          `
        }),
        entryPoint: 'main'
      }
    });

    // Textness classification
    this.pipelines.classify = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var swtTexture: texture_2d<f32>;
            @group(0) @binding(1) var lbpTexture: texture_2d<u32>;
            @group(0) @binding(2) var textnessTexture: texture_storage_2d<r32float, write>;

            @compute @workgroup_size(8, 8)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(swtTexture);
              if (id.x >= dims.x || id.y >= dims.y) { return; }

              // SWT features
              let swt = textureLoad(swtTexture, vec2<i32>(id.xy), 0).r;
              
              // Analyze local SWT variance
              var swtSum = 0.0;
              var swtCount = 0.0;
              let windowSize = 5;
              
              for (var dy = -windowSize; dy <= windowSize; dy++) {
                for (var dx = -windowSize; dx <= windowSize; dx++) {
                  let px = i32(id.x) + dx;
                  let py = i32(id.y) + dy;
                  if (px >= 0 && px < i32(dims.x) && py >= 0 && py < i32(dims.y)) {
                    let localSwt = textureLoad(swtTexture, vec2<i32>(px, py), 0).r;
                    if (localSwt > 0.0) {
                      swtSum += localSwt;
                      swtCount += 1.0;
                    }
                  }
                }
              }

              var swtScore = 0.0;
              if (swtCount > 5.0 && swt > 0.0) {
                let meanSwt = swtSum / swtCount;
                let variance = abs(swt - meanSwt) / meanSwt;
                
                // Text has consistent stroke width
                swtScore = select(0.0, 1.0 - variance, variance < 0.5);
              }

              // LBP features for texture
              let lbp = textureLoad(lbpTexture, vec2<i32>(id.xy), 0).r;
              
              // Count transitions in LBP (text has specific patterns)
              var transitions = 0u;
              for (var i = 0u; i < 7u; i++) {
                let bit1 = (lbp >> i) & 1u;
                let bit2 = (lbp >> (i + 1u)) & 1u;
                if (bit1 != bit2) {
                  transitions += 1u;
                }
              }
              
              // Uniform patterns (0-2 transitions) are common in text
              let lbpScore = select(0.3, 0.9, transitions <= 2u);

              // Combine scores
              let textnessScore = 0.6 * swtScore + 0.4 * lbpScore;
              
              textureStore(textnessTexture, vec2<i32>(id.xy), vec4<f32>(textnessScore));
            }
          `
        }),
        entryPoint: 'main'
      }
    });

    // Gaussian blur for smoothing
    this.pipelines.blur = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var inputTexture: texture_2d<f32>;
            @group(0) @binding(1) var outputTexture: texture_storage_2d<r32float, write>;

            const kernel = array<f32, 25>(
              1.0/256.0,  4.0/256.0,  6.0/256.0,  4.0/256.0, 1.0/256.0,
              4.0/256.0, 16.0/256.0, 24.0/256.0, 16.0/256.0, 4.0/256.0,
              6.0/256.0, 24.0/256.0, 36.0/256.0, 24.0/256.0, 6.0/256.0,
              4.0/256.0, 16.0/256.0, 24.0/256.0, 16.0/256.0, 4.0/256.0,
              1.0/256.0,  4.0/256.0,  6.0/256.0,  4.0/256.0, 1.0/256.0
            );

            @compute @workgroup_size(8, 8)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(inputTexture);
              if (id.x >= dims.x || id.y >= dims.y) { return; }

              var sum = 0.0;
              var idx = 0;
              
              for (var dy = -2; dy <= 2; dy++) {
                for (var dx = -2; dx <= 2; dx++) {
                  let px = clamp(i32(id.x) + dx, 0, i32(dims.x) - 1);
                  let py = clamp(i32(id.y) + dy, 0, i32(dims.y) - 1);
                  let pixel = textureLoad(inputTexture, vec2<i32>(px, py), 0).r;
                  sum += pixel * kernel[idx];
                  idx++;
                }
              }

              textureStore(outputTexture, vec2<i32>(id.xy), vec4<f32>(sum));
            }
          `
        }),
        entryPoint: 'main'
      }
    });
  }

  async compute(imageData) {
    const { width, height } = imageData;

    // Create input texture
    const inputTexture = this.gpu.createTexture({
      size: { width, height },
      format: 'rgba8unorm',
      usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST
    });

    this.gpu.queue.writeTexture(
      { inputTexture },
      imageData.data,
      { bytesPerRow: width * 4 },
      { width, height }
    );

    // Compute gradients for SWT
    const { edgeTexture, gradientTexture } = await this.computeGradients(inputTexture, width, height);

    // Compute SWT
    const swtTexture = this.gpu.createTexture({
      size: { width, height },
      format: 'r32float',
      usage: GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.TEXTURE_BINDING
    });

    let bindGroup = this.gpu.createBindGroup(
      this.pipelines.swt.getBindGroupLayout(0),
      [
        { binding: 0, resource: edgeTexture.createView() },
        { binding: 1, resource: gradientTexture.createView() },
        { binding: 2, resource: swtTexture.createView() }
      ]
    );

    let encoder = this.gpu.createCommandEncoder();
    let pass = encoder.beginComputePass();
    pass.setPipeline(this.pipelines.swt);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(width / 8), Math.ceil(height / 8));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    // Compute LBP
    const lbpTexture = this.gpu.createTexture({
      size: { width, height },
      format: 'r8uint',
      usage: GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.TEXTURE_BINDING
    });

    bindGroup = this.gpu.createBindGroup(
      this.pipelines.lbp.getBindGroupLayout(0),
      [
        { binding: 0, resource: inputTexture.createView() },
        { binding: 1, resource: lbpTexture.createView() }
      ]
    );

    encoder = this.gpu.createCommandEncoder();
    pass = encoder.beginComputePass();
    pass.setPipeline(this.pipelines.lbp);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(width / 8), Math.ceil(height / 8));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    // Classify textness
    const textnessTexture = this.gpu.createTexture({
      size: { width, height },
      format: 'r32float',
      usage: GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.TEXTURE_BINDING
    });

    bindGroup = this.gpu.createBindGroup(
      this.pipelines.classify.getBindGroupLayout(0),
      [
        { binding: 0, resource: swtTexture.createView() },
        { binding: 1, resource: lbpTexture.createView() },
        { binding: 2, resource: textnessTexture.createView() }
      ]
    );

    encoder = this.gpu.createCommandEncoder();
    pass = encoder.beginComputePass();
    pass.setPipeline(this.pipelines.classify);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(width / 8), Math.ceil(height / 8));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    // Blur for smoothing
    const smoothTexture = this.gpu.createTexture({
      size: { width, height },
      format: 'r32float',
      usage: GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.COPY_SRC
    });

    bindGroup = this.gpu.createBindGroup(
      this.pipelines.blur.getBindGroupLayout(0),
      [
        { binding: 0, resource: textnessTexture.createView() },
        { binding: 1, resource: smoothTexture.createView() }
      ]
    );

    encoder = this.gpu.createCommandEncoder();
    pass = encoder.beginComputePass();
    pass.setPipeline(this.pipelines.blur);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(width / 8), Math.ceil(height / 8));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    // Cleanup intermediate textures
    inputTexture.destroy();
    edgeTexture.destroy();
    gradientTexture.destroy();
    swtTexture.destroy();
    lbpTexture.destroy();
    textnessTexture.destroy();

    return smoothTexture;
  }

  async computeGradients(inputTexture, width, height) {
    const edgeTexture = this.gpu.createTexture({
      size: { width, height },
      format: 'r32float',
      usage: GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.TEXTURE_BINDING
    });

    const gradientTexture = this.gpu.createTexture({
      size: { width, height },
      format: 'rg32float',
      usage: GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.TEXTURE_BINDING
    });

    const pipeline = this.gpu.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpu.device.createShaderModule({
          code: `
            @group(0) @binding(0) var inputTex: texture_2d<f32>;
            @group(0) @binding(1) var edgeTex: texture_storage_2d<r32float, write>;
            @group(0) @binding(2) var gradTex: texture_storage_2d<rg32float, write>;

            @compute @workgroup_size(8, 8)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(inputTex);
              if (id.x >= dims.x - 1 || id.y >= dims.y - 1 || id.x == 0 || id.y == 0) {
                return;
              }

              let tl = textureLoad(inputTex, vec2<i32>(i32(id.x) - 1, i32(id.y) - 1), 0).r;
              let t  = textureLoad(inputTex, vec2<i32>(i32(id.x), i32(id.y) - 1), 0).r;
              let tr = textureLoad(inputTex, vec2<i32>(i32(id.x) + 1, i32(id.y) - 1), 0).r;
              let l  = textureLoad(inputTex, vec2<i32>(i32(id.x) - 1, i32(id.y)), 0).r;
              let r  = textureLoad(inputTex, vec2<i32>(i32(id.x) + 1, i32(id.y)), 0).r;
              let bl = textureLoad(inputTex, vec2<i32>(i32(id.x) - 1, i32(id.y) + 1), 0).r;
              let b  = textureLoad(inputTex, vec2<i32>(i32(id.x), i32(id.y) + 1), 0).r;
              let br = textureLoad(inputTex, vec2<i32>(i32(id.x) + 1, i32(id.y) + 1), 0).r;

              let gx = -tl - 2.0 * l - bl + tr + 2.0 * r + br;
              let gy = -tl - 2.0 * t - tr + bl + 2.0 * b + br;
              
              let magnitude = sqrt(gx * gx + gy * gy);

              textureStore(edgeTex, vec2<i32>(id.xy), vec4<f32>(magnitude));
              textureStore(gradTex, vec2<i32>(id.xy), vec4<f32>(gx, gy, 0.0, 0.0));
            }
          `
        }),
        entryPoint: 'main'
      }
    });

    const bindGroup = this.gpu.createBindGroup(
      pipeline.getBindGroupLayout(0),
      [
        { binding: 0, resource: inputTexture.createView() },
        { binding: 1, resource: edgeTexture.createView() },
        { binding: 2, resource: gradientTexture.createView() }
      ]
    );

    const encoder = this.gpu.createCommandEncoder();
    const pass = encoder.beginComputePass();
    pass.setPipeline(pipeline);
    pass.setBindGroup(0, bindGroup);
    pass.dispatchWorkgroups(Math.ceil(width / 8), Math.ceil(height / 8));
    pass.end();
    this.gpu.submit([encoder.finish()]);

    return { edgeTexture, gradientTexture };
  }

  dispose() {
    // Managed by GPU context
  }
}
