/**
 * OCR-WebGPU Main Pipeline
 * Complete GPU-accelerated OCR system
 */

import { GPUContext } from './core/gpuContext.js';
import { IQA } from './stages/01_iqa.js';
import { OrientationScript } from './stages/02_orientation_script.js';
import { Textness } from './stages/03_textness.js';
import { AdaptiveEnhance } from './stages/04_adaptive_enhance.js';
import { DBNet } from './stages/05_dbnet.js';
import { PolygonExtract } from './stages/06_polygon_extract.js';
import { UnclipScore } from './stages/07_unclip_score.js';
import { Deskew } from './stages/08_deskew.js';
import { LineCrop } from './stages/09_line_crop.js';
import { LineNormalize } from './stages/10_line_normalize.js';
import { SuperResolution } from './stages/11_super_resolution.js';
import { OCRTransformer } from './stages/12_ocr_transformer.js';
import { ConfidenceFeedback } from './stages/13_confidence_feedback.js';
import { LayoutEngine } from './layout/layout_engine.js';

export class OCRPipeline {
  constructor() {
    this.gpuContext = null;
    this.stages = {};
    this.layoutEngine = null;
  }

  async initialize() {
    // Initialize GPU context
    this.gpuContext = new GPUContext();
    await this.gpuContext.initialize();

    // Initialize all pipeline stages
    this.stages.iqa = new IQA(this.gpuContext);
    this.stages.orientation = new OrientationScript(this.gpuContext);
    this.stages.textness = new Textness(this.gpuContext);
    this.stages.enhance = new AdaptiveEnhance(this.gpuContext);
    this.stages.dbnet = new DBNet(this.gpuContext);
    this.stages.polygonExtract = new PolygonExtract(this.gpuContext);
    this.stages.unclip = new UnclipScore(this.gpuContext);
    this.stages.deskew = new Deskew(this.gpuContext);
    this.stages.lineCrop = new LineCrop(this.gpuContext);
    this.stages.lineNormalize = new LineNormalize(this.gpuContext);
    this.stages.superRes = new SuperResolution(this.gpuContext);
    this.stages.ocrTransformer = new OCRTransformer(this.gpuContext);
    this.stages.confidence = new ConfidenceFeedback(this.gpuContext);

    // Initialize layout engine
    this.layoutEngine = new LayoutEngine(this.gpuContext);

    await Promise.all([
      this.stages.iqa.initialize(),
      this.stages.orientation.initialize(),
      this.stages.textness.initialize(),
      this.stages.enhance.initialize(),
      this.stages.dbnet.initialize(),
      this.stages.polygonExtract.initialize(),
      this.stages.unclip.initialize(),
      this.stages.deskew.initialize(),
      this.stages.lineCrop.initialize(),
      this.stages.lineNormalize.initialize(),
      this.stages.superRes.initialize(),
      this.stages.ocrTransformer.initialize(),
      this.stages.confidence.initialize(),
      this.layoutEngine.initialize()
    ]);

    console.log('OCR Pipeline initialized');
  }

  async processImage(imageData) {
    const results = {
      metadata: {},
      textRegions: [],
      text: '',
      confidence: 0,
      layout: null
    };

    try {
      // Stage 1: Image Quality Assessment
      const iqaScore = await this.stages.iqa.assess(imageData);
      results.metadata.quality = iqaScore;
      
      if (iqaScore.overall < 0.3) {
        console.warn('Image quality too low for reliable OCR');
      }

      // Stage 2: Orientation and Script Detection
      const orientation = await this.stages.orientation.detect(imageData);
      results.metadata.orientation = orientation;

      // Rotate if needed
      let processedImage = imageData;
      if (orientation.angle !== 0) {
        processedImage = await this.rotateImage(imageData, orientation.angle);
      }

      // Stage 3: Textness Map Generation
      const textnessMap = await this.stages.textness.compute(processedImage);
      
      // Stage 4: Adaptive Enhancement
      const enhanced = await this.stages.enhance.process(processedImage, textnessMap);

      // Stage 5: Text Detection (DBNet)
      const detectionMap = await this.stages.dbnet.detect(enhanced);

      // Stage 6: Polygon Extraction
      const polygons = await this.stages.polygonExtract.extract(detectionMap);
      results.metadata.detectedRegions = polygons.length;

      // Stage 7: Unclip and Score
      const scoredPolygons = await this.stages.unclip.process(polygons, detectionMap);

      // Stage 8: Deskew individual regions
      const deskewedRegions = await this.stages.deskew.processRegions(
        enhanced, 
        scoredPolygons
      );

      // Stage 9: Line Cropping
      const lineRegions = await this.stages.lineCrop.extractLines(deskewedRegions);

      // Stage 10: Line Normalization
      const normalized = await this.stages.lineNormalize.normalize(lineRegions);

      // Stage 11: Super Resolution (for small text)
      const highRes = await this.stages.superRes.upscale(normalized);

      // Stage 12: OCR Transformer Recognition
      const recognitionResults = await this.stages.ocrTransformer.recognize(highRes);

      // Stage 13: Confidence Feedback
      const finalResults = await this.stages.confidence.refine(
        recognitionResults,
        detectionMap
      );

      // Layout Analysis
      const layout = await this.layoutEngine.analyze(
        finalResults,
        processedImage.width,
        processedImage.height
      );

      // Assemble final results
      results.textRegions = finalResults.regions;
      results.text = finalResults.text;
      results.confidence = finalResults.confidence;
      results.layout = layout;

      return results;

    } catch (error) {
      console.error('OCR Pipeline error:', error);
      throw error;
    }
  }

  async rotateImage(imageData, angle) {
    // GPU-accelerated rotation
    const pipeline = this.gpuContext.device.createComputePipeline({
      layout: 'auto',
      compute: {
        module: this.gpuContext.device.createShaderModule({
          code: `
            @group(0) @binding(0) var inputTexture: texture_2d<f32>;
            @group(0) @binding(1) var outputTexture: texture_storage_2d<rgba8unorm, write>;
            @group(0) @binding(2) var<uniform> rotation: mat2x2<f32>;

            @compute @workgroup_size(8, 8)
            fn main(@builtin(global_invocation_id) id: vec3<u32>) {
              let dims = textureDimensions(inputTexture);
              if (id.x >= dims.x || id.y >= dims.y) { return; }

              let center = vec2<f32>(f32(dims.x) * 0.5, f32(dims.y) * 0.5);
              let pos = vec2<f32>(f32(id.x), f32(id.y)) - center;
              let rotated = rotation * pos + center;
              
              if (rotated.x >= 0.0 && rotated.x < f32(dims.x) && 
                  rotated.y >= 0.0 && rotated.y < f32(dims.y)) {
                let texCoord = vec2<i32>(i32(rotated.x), i32(rotated.y));
                let pixel = textureLoad(inputTexture, texCoord, 0);
                textureStore(outputTexture, vec2<i32>(id.xy), pixel);
              }
            }
          `
        }),
        entryPoint: 'main'
      }
    });

    // Execute rotation (simplified - full implementation would handle buffer management)
    // ... rotation execution code ...
    
    return imageData; // Placeholder
  }

  dispose() {
    Object.values(this.stages).forEach(stage => {
      if (stage.dispose) stage.dispose();
    });
    if (this.layoutEngine) this.layoutEngine.dispose();
    if (this.gpuContext) this.gpuContext.dispose();
  }
}

// Usage example
export async function runOCR(imageElement) {
  const pipeline = new OCRPipeline();
  await pipeline.initialize();

  // Convert image to ImageData
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  canvas.width = imageElement.width;
  canvas.height = imageElement.height;
  ctx.drawImage(imageElement, 0, 0);
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

  const results = await pipeline.processImage(imageData);
  
  console.log('OCR Results:', results);
  
  pipeline.dispose();
  
  return results;
}
